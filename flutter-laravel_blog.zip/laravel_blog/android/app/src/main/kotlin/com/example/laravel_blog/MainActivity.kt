package com.example.laravel_blog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
