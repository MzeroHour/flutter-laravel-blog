import 'package:flutter/material.dart';
import 'package:laravel_blog/model/api_response.dart';
import 'package:laravel_blog/model/user.dart';
import 'package:laravel_blog/screens/home.dart';
import 'package:laravel_blog/screens/login.dart';
import 'package:laravel_blog/services/user_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../constant.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool loading = false;
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordConfirmController = TextEditingController();

  void _registerUser() async {
    ApiResponse response = await register(
        nameController.text, emailController.text, passwordController.text);
    if (response.error == null) {
      _saveAndRedirectToHome(response.data as User);
    } else {
      setState(() {
        loading = !loading;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${response.error}'),
      ));
    }
  }

  void _saveAndRedirectToHome(User user) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    await pref.setString('token', user.token ?? '');
    await pref.setInt('userId', user.id ?? 0);
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => Home()), (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register'),
        centerTitle: true,
      ),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(32),
          children: [
            TextFormField(
              keyboardType: TextInputType.name,
              controller: nameController,
              validator: (value) => value!.isEmpty ? 'Require Name!' : null,
              decoration: kInputDecoration('Name'),
            ),
            const SizedBox(
              height: 10,
            ),
            TextFormField(
              keyboardType: TextInputType.emailAddress,
              controller: emailController,
              validator: (value) =>
                  value!.isEmpty ? 'Invalid email address' : null,
              decoration: kInputDecoration('Email'),
            ),
            const SizedBox(
              height: 10,
            ),
            TextFormField(
              controller: passwordController,
              obscureText: true,
              validator: (value) =>
                  value!.length < 6 ? 'Required at lest 6 character' : null,
              decoration: kInputDecoration('Confirm Password'),
            ),
            const SizedBox(
              height: 10,
            ),
            TextFormField(
              controller: passwordConfirmController,
              obscureText: true,
              validator: (value) => value != passwordController.text
                  ? 'Confirm Password does not Match!'
                  : null,
              decoration: kInputDecoration('Password'),
            ),
            SizedBox(
              height: 10,
            ),
            loading
                ? Center(
                    child: CircularProgressIndicator(),
                  )
                : kTextButton('Register', () {
                    if (formKey.currentState!.validate()) {
                      loading = !loading;
                      _registerUser();
                    }
                  }),
            const SizedBox(
              height: 10,
            ),
            kLoginRegisterHint('Do not have account? ', 'Register', () {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => Login()),
                  (route) => false);
            })
          ],
        ),
      ),
    );
  }
}
