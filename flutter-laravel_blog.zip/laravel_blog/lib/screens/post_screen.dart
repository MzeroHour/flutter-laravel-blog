import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:laravel_blog/constant.dart';
import 'package:laravel_blog/model/api_response.dart';
import 'package:laravel_blog/model/post.dart';
import 'package:laravel_blog/screens/comment_screen.dart';
import 'package:laravel_blog/screens/login.dart';
import 'package:laravel_blog/screens/post_form.dart';
import 'package:laravel_blog/services/post_service.dart';
import 'package:laravel_blog/services/user_service.dart';

class PostScreen extends StatefulWidget {
  const PostScreen({super.key});

  @override
  State<PostScreen> createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  List<dynamic> _postList = [];
  int userId = 0;
  bool _loading = true;

  //Get all post
  Future<void> retrievePosts() async {
    userId = await getUserId();
    ApiResponse response = await getPost();

    if (response.error == null) {
      setState(() {
        _postList = response.data as List<dynamic>;
        _loading = _loading ? !_loading : _loading;
      });
    } else if (response.error == unauthorized) {
      logout().then((value) => {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => Login(),
                ),
                (route) => false)
          });
    } else {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${response.error}'),
        ),
      );
    }
  }

  //Delete Post
  void _handleDeletePost(int postId) async {
    ApiResponse response = await deletePost(postId);
    if (response.error == null) {
      retrievePosts();
    } else if (response.error == unauthorized) {
      logout().then((value) => {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => Login(),
                ),
                (route) => false)
          });
    } else {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${response.error}'),
        ),
      );
    }
  }

  //post like and dislike
  void _handleLikeAndDislike(int postId) async {
    ApiResponse response = await likeUnlikePost(postId);
    if (response.error == null) {
      retrievePosts();
    } else if (response.error == unauthorized) {
      logout().then((value) => {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => Login(),
                ),
                (route) => false),
          });
    } else {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${response.error}'),
        ),
      );
    }
  }

  @override
  void initState() {
    retrievePosts();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: () {
              return retrievePosts();
            },
            child: ListView.builder(
                itemCount: _postList.length,
                itemBuilder: (BuildContext context, int index) {
                  Post post = _postList[index];
                  return Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 20,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 6),
                              child: Row(
                                children: [
                                  Container(
                                    width: 38,
                                    height: 38,
                                    child: post.user!.image != null
                                        ? CachedNetworkImage(
                                            key:
                                                ValueKey('${post.user!.image}'),
                                            imageUrl: '${post.user!.image}',
                                            fit: BoxFit.cover,
                                            fadeInDuration:
                                                const Duration(seconds: 6),
                                            maxHeightDiskCache: 100,
                                            imageBuilder:
                                                (context, imageProvider) =>
                                                    Container(
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  image: imageProvider,
                                                  fit: BoxFit.cover,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(25),
                                              ),
                                            ),
                                            progressIndicatorBuilder:
                                                (context, url, progress) {
                                              return ColoredBox(
                                                color: Colors.black12,
                                                child: Center(
                                                  child:
                                                      CircularProgressIndicator(
                                                          value: progress
                                                              .progress),
                                                ),
                                              );
                                            },
                                            errorWidget:
                                                (context, url, error) =>
                                                    const ColoredBox(
                                              color: Colors.grey,
                                              child: Icon(
                                                Icons.error_outline,
                                                size: 20,
                                                color: Colors.white,
                                              ),
                                            ),
                                          )
                                        : Container(
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(25),
                                                color: Colors.amber),
                                          ),

                                    // decoration: BoxDecoration(
                                    //   image: post.user!.image != null
                                    //       ? DecorationImage(
                                    //           image: NetworkImage(
                                    //               '${post.user!.image}'),
                                    //         )
                                    //       : null,
                                    //   borderRadius: BorderRadius.circular(25),
                                    //   color: Colors.amber,
                                    // ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '${post.user!.name}',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            post.user!.id == userId
                                ? PopupMenuButton(
                                    child: const Padding(
                                      padding: EdgeInsets.only(right: 10),
                                      child: Icon(
                                        Icons.more_vert,
                                        color: Colors.black,
                                      ),
                                    ),
                                    itemBuilder: (context) => [
                                      const PopupMenuItem(
                                        child: Text('Edit'),
                                        value: 'edit',
                                      ),
                                      const PopupMenuItem(
                                        child: Text('Delete'),
                                        value: 'delete',
                                      )
                                    ],
                                    onSelected: (value) {
                                      if (value == 'edit') {
                                        //Edit
                                        Navigator.of(context)
                                            .push(MaterialPageRoute(
                                                builder: (context) => PostForm(
                                                      title: 'Edit Post',
                                                      post: post,
                                                    )));
                                      } else {
                                        //Delete
                                        _handleDeletePost(post.id ?? 0);
                                      }
                                    },
                                  )
                                : const SizedBox(),
                          ],
                        ),
                        const SizedBox(
                          height: 12,
                        ),
                        Text(
                          '${post.body}',
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        post.image != null
                            ? CachedNetworkImage(
                                key: ValueKey('${post.image}'),
                                imageUrl: '${post.image}',
                                width: MediaQuery.of(context).size.width,
                                height: 250,
                                fit: BoxFit.cover,
                                fadeInDuration: const Duration(seconds: 2),
                                maxHeightDiskCache: 300,
                                imageBuilder: (context, imageProvider) =>
                                    Container(
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: imageProvider,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                progressIndicatorBuilder:
                                    (context, url, progress) {
                                  return ColoredBox(
                                    color: Colors.black12,
                                    child: Center(
                                      child: CircularProgressIndicator(
                                          value: progress.progress),
                                    ),
                                  );
                                },
                                errorWidget: (context, url, error) =>
                                    const ColoredBox(
                                  color: Colors.grey,
                                  child: Icon(
                                    Icons.error_outline,
                                    size: 50,
                                    color: Colors.white,
                                  ),
                                ),
                              )
                            // Container(
                            //     width: MediaQuery.of(context).size.width,
                            //     height: 180,
                            //     margin: EdgeInsets.only(top: 5),
                            //     decoration: BoxDecoration(
                            //       image: DecorationImage(
                            //           image: NetworkImage('${post.image}'),
                            //           fit: BoxFit.cover),
                            //     ),
                            //   )
                            : SizedBox(height: post.image != null ? 0 : 10),
                        Row(
                          children: [
                            likeAndComment(
                              post.likesCount ?? 0,
                              post.selfLiked == true
                                  //Check Icon
                                  ? Icons.favorite
                                  : Icons.favorite_outline,
                              post.selfLiked == true
                                  //Check Color
                                  ? Colors.red
                                  : Colors.black38,
                              () {
                                _handleLikeAndDislike(post.id ?? 0);
                              },
                            ),
                            Container(
                              height: 25,
                              width: 0.5,
                              color: Colors.black38,
                            ),
                            likeAndComment(
                              post.commentsCount ?? 0,
                              Icons.sms_outlined,
                              Colors.black38,
                              () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (context) => CommentScreen(
                                          postId: post.id,
                                        )));
                              },
                            ),
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 0.5,
                          color: Colors.black38,
                        ),
                      ],
                    ),
                  );
                }),
          );
  }

//Cache Clear
  void clearCache() {
    DefaultCacheManager().emptyCache();
    imageCache.clear();
    imageCache.clearLiveImages();
    setState(() {});
  }
}
